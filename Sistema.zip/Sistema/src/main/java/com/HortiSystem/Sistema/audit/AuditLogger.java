package com.HortiSystem.Sistema.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import jakarta.servlet.http.HttpServletRequest;

@Component
public class AuditLogger {

    private static final Logger auditLogger = LoggerFactory.getLogger("com.HortiSystem.Sistema.audit");

    public void logLogin(String username, boolean success, HttpServletRequest request) {
        MDC.put("userId", username);
        MDC.put("userIp", getClientIp(request));
        MDC.put("action", "LOGIN_" + (success ? "SUCCESS" : "FAILURE"));

        auditLogger.info("Tentativa de login - Sucesso: {}", success);

        MDC.clear();
    }

    private String getClientIp(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader != null) {
            return xfHeader.split(",")[0];
        }
        return request.getRemoteAddr();
    }
}