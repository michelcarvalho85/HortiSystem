package com.HortiSystem.Sistema.config;

import com.HortiSystem.Sistema.model.Produto;
import com.HortiSystem.Sistema.model.Usuario;
import com.HortiSystem.Sistema.repository.ProdutoRepository;
import com.HortiSystem.Sistema.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
import java.util.Arrays;

/**
 * INICIALIZADOR DE DADOS - Cria dados iniciais no banco
 * Agora cria usuários E produtos de exemplo
 */
@Configuration
public class DataInitializer {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    /**
     * BEAN SEPARADO para o PasswordEncoder
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * BEAN para inicializar dados - Usuários e Produtos
     */
    @Bean
    public CommandLineRunner initData() {
        return args -> {
            criarUsuarios();
            criarProdutos();
        };
    }

    /**
     * CRIA USUÁRIOS INICIAIS
     */
    private void criarUsuarios() {
        // ✅ USUÁRIO ADMIN
        if (usuarioRepository.findByUsername("admin").isEmpty()) {
            Usuario admin = new Usuario();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder().encode("admin123")); // Senha: admin123
            admin.setEmail("admin@hortisystem.com");
            admin.setRole("ADMIN");
            admin.setAtivo(true);

            usuarioRepository.save(admin);
            System.out.println("=== USUÁRIO ADMIN CRIADO ===");
            System.out.println("Usuário: admin");
            System.out.println("Senha: admin123");
            System.out.println("Role: ADMIN");
            System.out.println("=============================");
        }

        // ✅ USUÁRIO VENDEDOR
        if (usuarioRepository.findByUsername("vendedor").isEmpty()) {
            Usuario vendedor = new Usuario();
            vendedor.setUsername("vendedor");
            vendedor.setPassword(passwordEncoder().encode("vendedor123")); // Senha: vendedor123
            vendedor.setEmail("vendedor@hortisystem.com");
            vendedor.setRole("VENDEDOR");
            vendedor.setAtivo(true);

            usuarioRepository.save(vendedor);
            System.out.println("=== USUÁRIO VENDEDOR CRIADO ===");
            System.out.println("Usuário: vendedor");
            System.out.println("Senha: vendedor123");
            System.out.println("Role: VENDEDOR");
            System.out.println("===============================");
        }

        // ✅ USUÁRIO ESTOQUISTA
        if (usuarioRepository.findByUsername("estoquista").isEmpty()) {
            Usuario estoquista = new Usuario();
            estoquista.setUsername("estoquista");
            estoquista.setPassword(passwordEncoder().encode("estoque123")); // Senha: estoque123
            estoquista.setEmail("estoquista@hortisystem.com");
            estoquista.setRole("ESTOQUISTA");
            estoquista.setAtivo(true);

            usuarioRepository.save(estoquista);
            System.out.println("=== USUÁRIO ESTOQUISTA CRIADO ===");
            System.out.println("Usuário: estoquista");
            System.out.println("Senha: estoque123");
            System.out.println("Role: ESTOQUISTA");
            System.out.println("=================================");
        }
    }

    /**
     * CRIA PRODUTOS INICIAIS
     */
    private void criarProdutos() {
        if (produtoRepository.count() == 0) {
            // ✅ PRODUTOS DE HORTIFRUTI
            Produto tomate = new Produto();
            tomate.setNome("Tomate");
            tomate.setQuantidade(100);
            tomate.setValor(new BigDecimal("4.50"));
            tomate.setUnidadeMedida(com.HortiSystem.Sistema.model.UnidadeMedida.KG);
            tomate.setCategoria("Hortaliças");

            Produto alface = new Produto();
            alface.setNome("Alface Crespa");
            alface.setQuantidade(50);
            alface.setValor(new BigDecimal("2.80"));
            alface.setUnidadeMedida(com.HortiSystem.Sistema.model.UnidadeMedida.UN);
            alface.setCategoria("Hortaliças");

            Produto banana = new Produto();
            banana.setNome("Banana Prata");
            banana.setQuantidade(80);
            banana.setValor(new BigDecimal("3.20"));
            banana.setUnidadeMedida(com.HortiSystem.Sistema.model.UnidadeMedida.KG);
            banana.setCategoria("Frutas");

            Produto laranja = new Produto();
            laranja.setNome("Laranja Pera");
            laranja.setQuantidade(60);
            laranja.setValor(new BigDecimal("2.50"));
            laranja.setUnidadeMedida(com.HortiSystem.Sistema.model.UnidadeMedida.KG);
            laranja.setCategoria("Frutas");

            Produto cenoura = new Produto();
            cenoura.setNome("Cenoura");
            cenoura.setQuantidade(40);
            cenoura.setValor(new BigDecimal("3.80"));
            cenoura.setUnidadeMedida(com.HortiSystem.Sistema.model.UnidadeMedida.KG);
            cenoura.setCategoria("Legumes");

            // Salva todos os produtos
            produtoRepository.saveAll(Arrays.asList(tomate, alface, banana, laranja, cenoura));

            System.out.println("=== PRODUTOS CRIADOS ===");
            System.out.println("✅ 5 produtos de hortifruti criados no banco");
            System.out.println("📦 Total de produtos: " + produtoRepository.count());
            System.out.println("========================");
        } else {
            System.out.println("✅ Produtos já existem no banco: " + produtoRepository.count() + " produtos");
        }
    }
}