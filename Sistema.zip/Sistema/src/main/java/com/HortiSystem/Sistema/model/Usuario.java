package com.HortiSystem.Sistema.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

/**
 * CLASSE ENTIDADE USUÁRIO - IMPLEMENTA USERDETAILS DO SPRING SECURITY
 * Esta classe representa um usuário do sistema e implementa a interface UserDetails
 * do Spring Security para integração com o sistema de autenticação
 */
@Entity // Indica que esta classe é uma entidade JPA (mapeia para tabela no banco)
@Getter // Lombok: gera getters automaticamente
@Setter // Lombok: gera setters automaticamente - ✅ ADICIONADO
public class Usuario implements UserDetails {

    /**
     * ATRIBUTOS DA ENTIDADE - COLUNAS DA TABELA USUARIO
     */
    @Id // Marca como chave primária
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Geração automática do ID
    private Long id;

    @Column(unique = true, nullable = false) // ✅ ADICIONADO: único e obrigatório
    private String username; // Nome de usuário para login

    @Column(nullable = false) // ✅ ADICIONADO: obrigatório
    private String password; // Senha criptografada

    private String email;    // Email do usuário

    private String role;     // Papel do usuário (ADMIN, VENDEDOR, etc.)

    private boolean ativo = true;   // Status do usuário (ativo/inativo)

    // ✅ CONSTRUTORES
    public Usuario() {}

    public Usuario(String username, String password, String email, String role) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.role = role;
        this.ativo = true;
    }

    /**
     * MÉTODO DA INTERFACE USERDETAILS - RETORNA AS AUTORIDADES/PERMISSÕES
     * Converte a role do usuário em uma GrantedAuthority para o Spring Security
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role));
    }

    /**
     * MÉTODOS DA INTERFACE USERDETAILS - CONTROLE DE SEGURANÇA
     */
    @Override
    public String getPassword() {
        return this.password; // Retorna a senha para autenticação
    }

    @Override
    public String getUsername() {
        return this.username; // Retorna o username para autenticação
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // Conta nunca expira
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Conta nunca é bloqueada
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Credenciais nunca expiram
    }

    @Override
    public boolean isEnabled() {
        return this.ativo; // Usuário está habilitado baseado no campo 'ativo'
    }

    // ✅ REMOVIDOS: Os setters problemáticos que estavam vazios
    // O Lombok (@Setter) agora gera os setters automaticamente
}