package com.HortiSystem.Sistema.config;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class AuthSuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        String username = authentication.getName();
        System.out.println("🎉 LOGIN BEM-SUCEDIDO - Usuário: " + username + " | IP: " + getClientIp(request));

        // Salva no arquivo de log também
        org.slf4j.LoggerFactory.getLogger("LOGIN_LOGGER")
                .info("LOGIN_SUCESSO | usuario: {} | ip: {}", username, getClientIp(request));

        response.sendRedirect("/");
    }

    private String getClientIp(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader != null) {
            return xfHeader.split(",")[0];
        }
        return request.getRemoteAddr();
    }
}